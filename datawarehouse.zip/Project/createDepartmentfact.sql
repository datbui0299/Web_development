create database DepartmentPositionSnapshotDW
use DepartmentPositionSnapshotDW
create table DimManager(
	managerKey INT IDENTITY  NOT NULL,
	--attributes
	manager_no int NOT NULL,
	manager_name varchar (60) NOT NULL,
	dept_no varchar (4) NOT NULL,
	from_date date,
	salary int ,
	--metadata
	[RowIsCurrent]  nchar(1)   NULL,
	[RowStartDate]  datetime   NULL,  
	[RowEndDate]  datetime  DEFAULT '31-Dec-9999' NULL,  
	[RowChangeReason]  nvarchar(200)   NULL, 
	CONSTRAINT [PK_emplyees.DimManager] PRIMARY KEY  CLUSTERED ( [managerKey] )
)
drop table DimManager
create table DimDepartment(
	departmentKey INT IDENTITY  NOT NULL,
	--attributes
	dept_no varchar(4) NOT NULL,
	dept_name varchar (255) NOT NULL,
	

	--metadata
	[RowIsCurrent]  nchar(1)   NULL,
	[RowStartDate]  datetime   NULL,  
	[RowEndDate]  datetime  DEFAULT '31-Dec-9999' NULL,  
	[RowChangeReason]  nvarchar(200)   NULL,
	--keys
	constraint pkDimDepartmentKey primary key (departmentKey)
)
drop table DimDepartment
create table FactDepartmentPositionSnapshot(

[DepartmentNo] varchar(4) not  null,
[Department Name] varchar(30) not null,
[departmentKey] INT NOT NULL,
[ManagerKey] int not null,
---measure
[Staff] int default '0' not null,
[Senior Staff]  int default '0' not null,
[Engineer] int default '0' not null,
[Senior Engineer] int default '0' not null,
[Assistant Engineer] int default '0' not null,
[Technique Leader] int default '0' not null,
CONSTRAINT [PK_employees.FactDepartmentPositionSnapshot] PRIMARY KEY NONCLUSTERED 
( [DepartmentNo] ),
	CONSTRAINT FK_employees_FactDepartmentPositionSnapshot_ManagerKey FOREIGN KEY
   ( ManagerKey) REFERENCES DimManager(managerKey),
   CONSTRAINT FK_employees_FactDepartmentPositionSnapshot_DepartmentKey FOREIGN KEY
   ( departmentKey) REFERENCES DimDepartment(departmentKey),
	
);
drop table FactDepartmentPositionSnapshot
