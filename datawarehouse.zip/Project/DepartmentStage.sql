create database DepartmentPositionSnapshotStage
use DepartmentPositionSnapshotStage

select a.emp_no, first_name +''+last_name as name,dept_no,a.from_date,salary
into DepartmentPositionSnapshotStage.[dbo].StageManager
from employees.dbo.dept_manager a join employees.dbo.employees b
on a.emp_no=b.emp_no
join employees.dbo.salaries c
on b.emp_no=c.emp_no
where year(a.to_date)=9999

drop table DepartmentPositionSnapshotStage.[dbo].StageManager

 
---stage dim department
select dept_no,dept_name
into DepartmentPositionSnapshotStage.[dbo].StageDepartment
from employees.dbo.departments
--stage

select a.dept_no,a.dept_name, sum( case when title='Staff' then 1 else 0 end) Staff, sum (case when title='Senior Staff' then 1 else 0 end) SeniorStaff,
sum( case when title='Engineer' then 1 else 0 end) Engineer,sum( case when title='Senior Engineer' then 1 else 0 end) Senior_Engineer,
sum( case when title='Assistant Engineer' then 1 else 0 end) Assistant_Engineer,sum( case when title='Technique Leader' then 1 else 0 end) Technique_Leader
into DepartmentPositionSnapshotStage.[dbo].StageFactDepartment
from employees.dbo.departments a, employees.dbo.dept_emp b, employees.dbo.employees c, employees.dbo.titles d
where a.dept_no=b.dept_no and b.emp_no=c.emp_no and c.emp_no=d.emp_no and YEAR(d.to_date)=9999
group by a.dept_no,a.dept_name

drop table DepartmentPositionSnapshotStage.[dbo].StageDepartment

select dept_no,dept_name
into 
from employees.dbo.departments
drop table DepartmentPositionSnapshotStage.[dbo].StageFactDepartment
