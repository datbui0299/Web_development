use DepartmentPositionSnapshotDW

insert into  DepartmentPositionSnapshotDW.dbo.DimManager
(manager_no,manager_name,dept_no,from_date,salary)
select emp_no,  name,dept_no,from_date,salary
from DepartmentPositionSnapshotStage.[dbo].StageManager

insert into DepartmentPositionSnapshotDW.dbo.DimDepartment
( dept_no,dept_name)
select  dept_no,dept_name 
 from DepartmentPositionSnapshotStage.[dbo].StageDepartment

insert into DepartmentPositionSnapshotDW.dbo.FactDepartmentPositionSnapshot
([DepartmentNo] ,[Department Name],[departmentKey] ,[ManagerKey],
[Staff],[Senior Staff],[Engineer],[Senior Engineer] ,[Assistant Engineer] ,[Technique Leader] )
select a.dept_no,a.dept_name,c.departmentKey,b.managerKey,Staff,  SeniorStaff,
 Engineer, Senior_Engineer,
 Assistant_Engineer, Technique_Leader
from DepartmentPositionSnapshotStage.[dbo].StageFactDepartment a
join DepartmentPositionSnapshotDW.dbo.DimManager b
on a.dept_no=b.dept_no 
join DepartmentPositionSnapshotDW.dbo.DimDepartment c
on a.dept_no=c.dept_no